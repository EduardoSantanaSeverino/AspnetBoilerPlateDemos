﻿namespace MyCollegeV2.Roles.Dto
{
    public class GetRolesInput
    {
        public string Permission { get; set; }
    }
}
